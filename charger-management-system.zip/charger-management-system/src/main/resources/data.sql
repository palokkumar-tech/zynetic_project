INSERT INTO charger (charger_id, status, last_status_update, last_heartbeat) VALUES
('charger1', 'Available', NOW(), NOW()),
('charger2', 'Charging', NOW(), NOW());

INSERT INTO charging_transaction (charger_id, user_id, start_time, end_time, energy_consumed) VALUES
('charger1', 'user123', NOW(), NOW(), 0),
('charger2', 'user456', NOW(), NOW(), 5);
