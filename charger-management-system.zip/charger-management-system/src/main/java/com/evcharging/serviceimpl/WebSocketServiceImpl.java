package com.evcharging.serviceimpl;

import com.evcharging.dto.*;
import com.evcharging.service.*;
import com.evcharging.util.OcppMessageParser;
import com.evcharging.util.OcppRequest;
import jakarta.websocket.Session;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class WebSocketServiceImpl implements WebSocketService {

    private final ChargerService chargerService;
    private final TransactionService transactionService;
    private final HeartbeatMonitorService heartbeatMonitorService;

    @Override
    public void registerSession(String chargerId, Session session) {
        chargerService.mapChargerToSession(chargerId, session.getId());
//        StartTransactionRequest.of().sessionId(session.getId()).
//       transactionService.startTransaction(chargerId,StartTransactionRequest req)
    }

    @Override
    public void handleMessage(Session session, String message, String chargerId) {
        OcppRequest request = OcppMessageParser.parse(message);
        String action = request.getAction();
        String uniqueId = request.getUniqueId();

        String response;
        try {
            switch (action) {
                case "BootNotification":
                    BootNotificationRequest boot = OcppMessageParser.objectMapper.treeToValue(request.getPayload(), BootNotificationRequest.class);
                    chargerService.registerCharger(boot, chargerId);
                   // response = OcppMessageParser.buildCallResult(uniqueId, new BootNotificationResponse("Accepted", LocalDateTime.now()));
                    break;
                case "Heartbeat":
                    chargerService.updateLastHeartbeat(chargerId);
                    heartbeatMonitorService.updateHeartbeat(chargerId);
                   // response = OcppMessageParser.buildCallResult(uniqueId, new HeartbeatResponse(LocalDateTime.now()));
                    break;
                case "StatusNotification":
                    StatusNotificationRequest statusReq = OcppMessageParser.objectMapper.treeToValue(request.getPayload(), StatusNotificationRequest.class);
                    chargerService.updateChargerStatus(chargerId, statusReq.getStatus());
                   // response = OcppMessageParser.buildCallResult(uniqueId, new StatusNotificationResponse("Accepted"));
                    break;
                case "StartTransaction":
                    StartTransactionRequest startReq = OcppMessageParser.objectMapper.treeToValue(request.getPayload(), StartTransactionRequest.class);
                    transactionService.startTransaction(chargerId, startReq);
                   // response = OcppMessageParser.buildCallResult(uniqueId, new StartTransactionResponse(startReq.getSessionId()));
                    break;
                case "StopTransaction":
                    StopTransactionRequest stopReq = OcppMessageParser.objectMapper.treeToValue(request.getPayload(), StopTransactionRequest.class);
                    transactionService.stopTransaction(chargerId, stopReq);
                   // response = OcppMessageParser.buildCallResult(uniqueId, new StopTransactionResponse(stopReq.getTransactionId()));
                    break;
                default:
                   // response = OcppMessageParser.buildCallError(uniqueId, "NotSupported", "Unsupported OCPP action");
            }
        } catch (Exception e) {
            log.error("Failed to process action {} from charger {}: {}", action, chargerId, e.getMessage(), e);
            response = OcppMessageParser.buildCallError(uniqueId, "InternalError", e.getMessage());
        }

        try {
           // session.getBasicRemote().sendText(response);
        } catch (Exception e) {
            log.error("Failed to send response to charger {}: {}", chargerId, e.getMessage(), e);
        }
    }
}
