package com.evcharging.serviceimpl;

import com.evcharging.dto.BootNotificationRequest;
import com.evcharging.model.Charger;
import com.evcharging.model.ChargerStatus;
import com.evcharging.repository.ChargerRepository;
import com.evcharging.service.ChargerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class ChargerServiceImpl implements ChargerService {

    private final ChargerRepository chargerRepository;

    @Override
    public void registerCharger(BootNotificationRequest request, String chargerId) {
        Charger charger = chargerRepository.findById(chargerId).orElse(new Charger());
        charger.setId(chargerId);
        charger.setManufacturer(request.getManufacturer());
        charger.setModel(request.getModel());
        charger.setStatus(ChargerStatus.AVAILABLE);
        charger.setLastHeartbeat(LocalDateTime.now());
        chargerRepository.save(charger);
        log.info("Charger {} registered", chargerId);
    }

    @Override
    public void updateLastHeartbeat(String chargerId) {
        chargerRepository.findById(chargerId).ifPresent(charger -> {
            charger.setLastHeartbeat(LocalDateTime.now());
            chargerRepository.save(charger);
        });
    }

    @Override
    public void updateChargerStatus(String chargerId, String status) {
        chargerRepository.findById(chargerId).ifPresent(charger -> {
            charger.setStatus(status);
            chargerRepository.save(charger);
        });
    }

    @Override
    public void mapChargerToSession(String chargerId, String sessionId) {
        chargerRepository.findById(chargerId).ifPresent(charger -> {
            charger.setSessionId(sessionId);
            chargerRepository.save(charger);
        });
    }

    @Override
    public Charger findByChargerId(String chargerId) {
        Charger charger = chargerRepository.findById(chargerId)
                .orElseThrow(() -> new RuntimeException("Charger not found"));
        return charger;
    }

    @Override
    public List<Charger> listAllChargers() {
        List<Charger> all = chargerRepository.findAll();
        return all;
    }
}