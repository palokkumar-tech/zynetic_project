package com.evcharging.serviceimpl;

import com.evcharging.model.Charger;
import com.evcharging.model.ChargerStatus;
import com.evcharging.service.ChargerService;
import com.evcharging.service.HeartbeatMonitorService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class HeartbeatMonitorServiceImpl implements HeartbeatMonitorService {

    private final ChargerService chargerService;
    private static final Duration TIMEOUT = Duration.ofMinutes(5);

    @Override
    public void updateHeartbeat(String chargerId) {

        chargerService.updateLastHeartbeat(chargerId);
    }

    @Scheduled(fixedRate = 60000)
    @Override
    public void markUnavailableIfNoHeartbeat() {
        List<Charger> chargers = chargerService.listAllChargers();
        LocalDateTime now = LocalDateTime.now();

        chargers.stream()
                .filter(charger -> charger.getLastHeartbeat() != null &&
                        Duration.between(charger.getLastHeartbeat(), now).compareTo(TIMEOUT) > 0 &&
                        charger.getStatus() != ChargerStatus.UNAVAILABLE)
                .forEach(charger -> chargerService.updateChargerStatus(charger.getId(), ChargerStatus.UNAVAILABLE.name()));
    }
}

