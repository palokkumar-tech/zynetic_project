package com.evcharging.serviceimpl;

import com.evcharging.dto.StartTransactionRequest;
import com.evcharging.dto.StopTransactionRequest;
import com.evcharging.model.Charger;
import com.evcharging.model.Transaction;
import com.evcharging.repository.ChargerRepository;
import com.evcharging.repository.TransactionRepository;
import com.evcharging.service.TransactionService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final ChargerRepository chargerRepository;

    @Override
    public Transaction startTransaction(String chargerId,StartTransactionRequest req) {
        Charger charger = chargerRepository.findByChargerId(chargerId)
                .orElseThrow(() -> new EntityNotFoundException("Charger not found"));

        Transaction tx = Transaction.builder()
                .charger(charger)
                .charger(charger)
                .startTime(LocalDateTime.now())
                .sessionId(req.getConnectorId())
                .energyConsumed(0.0)
                .build();

        return transactionRepository.save(tx);
    }

    @Override
    public void stopTransaction(String chargerId, StopTransactionRequest req) {
        Transaction tx = transactionRepository.findBySessionId(req.getTransactionId());

        if (tx == null) {
            throw new EntityNotFoundException("Transaction not found for sessionId: " + req.getTransactionId());
        }

        tx.setEndTime(LocalDateTime.now());

        if (req.getEnergyConsumed() != null) {
            tx.setEnergyConsumed(req.getEnergyConsumed());
        }

        transactionRepository.save(tx);
    }


    @Override
    public List<Transaction> findByChargerIdAndTimeRange(String chargerId, LocalDateTime from, LocalDateTime to) {
        return transactionRepository.findByCharger_ChargerIdAndStartTimeBetween(chargerId, from, to);
    }
}
