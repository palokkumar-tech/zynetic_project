package com.evcharging.config;

import com.evcharging.service.WebSocketService;
import com.evcharging.websocket.ChargerWebSocketEndpoint;
import com.evcharging.websocket.OcppWebSocketServerEndpoint;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;

@Configuration
@RequiredArgsConstructor
public class WebSocketConfig {

    private final WebSocketService webSocketService;

    @PostConstruct
    public void initEndpoints() {
        ChargerWebSocketEndpoint.setWebSocketService(webSocketService);
        OcppWebSocketServerEndpoint.setWebSocketService(webSocketService);
    }
}
