package com.evcharging.repository;


import com.evcharging.model.WebSocketSessionInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface WebSocketSessionInfoRepository extends JpaRepository<WebSocketSessionInfo, Long> {
    Optional<WebSocketSessionInfo> findByChargerId(String chargerId);
    void deleteByChargerId(String chargerId);
}
