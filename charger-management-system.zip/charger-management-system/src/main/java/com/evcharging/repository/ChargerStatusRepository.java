package com.evcharging.repository;

public class ChargerStatusRepository {
}
