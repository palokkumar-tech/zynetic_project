package com.evcharging.repository;


import com.evcharging.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByCharger_ChargerIdAndStartTimeBetween(String chargerId, LocalDateTime start, LocalDateTime end);

    Transaction findBySessionId(String transactionId);
}
