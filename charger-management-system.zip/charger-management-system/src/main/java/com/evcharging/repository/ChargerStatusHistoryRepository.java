package com.evcharging.repository;


import com.evcharging.model.ChargerStatusHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChargerStatusHistoryRepository extends JpaRepository<ChargerStatusHistory, Long> {
    List<ChargerStatusHistory> findByCharger_ChargerIdOrderByTimestampDesc(String chargerId);
}
