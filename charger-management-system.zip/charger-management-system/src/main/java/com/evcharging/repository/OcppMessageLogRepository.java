package com.evcharging.repository;


import com.evcharging.model.OcppMessageLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OcppMessageLogRepository extends JpaRepository<OcppMessageLog, Long> {
}
