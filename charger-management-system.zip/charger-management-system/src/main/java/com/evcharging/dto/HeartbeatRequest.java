package com.evcharging.dto;

import lombok.Data;

@Data
public class HeartbeatRequest {
    // No fields for HeartbeatRequest as per OCPP 1.6 spec
}
