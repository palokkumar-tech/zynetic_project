package com.evcharging.dto;


import lombok.Builder;
import lombok.Data;

@Data
@Builder(builderMethodName = "of")
public class StartTransactionRequest {
    private String connectorId;
    private String idTag;
    private String meterStart;
    private String timestamp;
    private String sessionId; // custom: generated unique session ID
}

