package com.evcharging.dto;


import lombok.Data;

@Data
public class BootNotificationRequest {
    private String chargePointModel;
    private String chargePointVendor;
    private String chargePointSerialNumber;
    private String firmwareVersion;
    private String model;
    private String manufacturer;


}

