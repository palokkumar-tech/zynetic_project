package com.evcharging.dto;


import lombok.Data;

@Data
public class StopTransactionRequest {
    private String meterStop;
    private String timestamp;
    private String reason;
    private String transactionId; // sessionId used as transaction ID
    private Double energyConsumed;
}

