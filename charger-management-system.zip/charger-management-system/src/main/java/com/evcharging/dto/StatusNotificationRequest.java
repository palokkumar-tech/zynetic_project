package com.evcharging.dto;


import lombok.Data;

@Data
public class StatusNotificationRequest {
    private String status; // Available, Charging, Faulted, etc.
    private int connectorId;
}
