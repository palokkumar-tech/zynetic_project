package com.evcharging.controller;

import com.evcharging.dto.ChargerDTO;
import com.evcharging.dto.TransactionDTO;
import com.evcharging.service.ChargerService;
import com.evcharging.service.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/chargers")
@RequiredArgsConstructor
public class ChargerController {

    private final ChargerService chargerService;
    private final TransactionService transactionService;

    // 1. Get all chargers with status
    @GetMapping
    public List<ChargerDTO> getAllChargers() {
        return chargerService.getAllChargers();
    }

    // 2. Get charger by ID (Optional)
    @GetMapping("/{chargerId}")
    public ChargerDTO getChargerById(@PathVariable String chargerId) {
        return chargerService.getChargerById(chargerId);
    }

    // 3. Get transaction history by charger ID and optional time range
    @GetMapping("/{chargerId}/transactions")
    public List<TransactionDTO> getTransactions(
            @PathVariable String chargerId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {
        return transactionService.getTransactionHistory(chargerId, from, to);
    }
}
