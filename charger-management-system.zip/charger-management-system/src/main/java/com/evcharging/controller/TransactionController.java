package com.evcharging.controller;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    private final TransactionLogRepository repository;

    public TransactionController(TransactionLogRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<TransactionLog> filterTransactions(
            @RequestParam(required = false) String chargerId,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {

        if (chargerId != null && from != null && to != null) {
            // Filter by chargerId and time range
            return repository.findByChargerIdAndStartTimeBetween(chargerId, from, to);
        } else if (chargerId != null) {
            // Filter by chargerId only
            return repository.findByChargerId(chargerId);
        } else if (from != null && to != null) {
            // Filter by time range only
            return repository.findByStartTimeBetween(from, to);
        } else {
            // Return all transactions if no filters are provided
            return repository.findAll();
        }
    }
}
