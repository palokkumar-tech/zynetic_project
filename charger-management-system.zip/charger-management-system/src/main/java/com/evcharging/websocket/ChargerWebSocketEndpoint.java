package com.evcharging.websocket;


import com.evcharging.service.WebSocketService;
import jakarta.websocket.*;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
@RequiredArgsConstructor
@ServerEndpoint(value = "/ws/charger/{chargerId}")
public class ChargerWebSocketEndpoint {

    private static final ConcurrentHashMap<String, Session> sessions = new ConcurrentHashMap<>();
    private static WebSocketService webSocketService;

    // This setter is used by Spring to inject the bean
    public static void setWebSocketService(WebSocketService service) {
        webSocketService = service;
    }

    @OnOpen
    public void onOpen(Session session, @PathParam("chargerId") String chargerId) {
        log.info("WebSocket connected: Charger ID {}", chargerId);
        sessions.put(chargerId, session);
        webSocketService.registerSession(chargerId, session);
    }

    @OnMessage
    public void onMessage(Session session, String message, @PathParam("chargerId") String chargerId) {
        log.info("Message received from {}: {}", chargerId, message);
        try {
            webSocketService.handleMessage(session,message,chargerId);
        } catch (Exception e) {
            log.error("Error processing message from {}: {}", chargerId, e.getMessage(), e);
            try {
                session.getBasicRemote().sendText("Error: " + e.getMessage());
            } catch (IOException ioException) {
                log.error("Failed to send error response", ioException);
            }
        }
    }

    @OnClose
    public void onClose(Session session, @PathParam("chargerId") String chargerId) {
        log.info("WebSocket disconnected: Charger ID {}", chargerId);
        sessions.remove(chargerId);
        webSocketService.handleDisconnect(chargerId);
    }

    @OnError
    public void onError(Session session, Throwable throwable, @PathParam("chargerId") String chargerId) {
        log.error("WebSocket error for charger {}: {}", chargerId, throwable.getMessage(), throwable);
    }

    public static Session getSession(String chargerId) {
        return sessions.get(chargerId);
    }
}
