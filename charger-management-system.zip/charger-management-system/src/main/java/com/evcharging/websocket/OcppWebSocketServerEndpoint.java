package com.evcharging.websocket;

import com.evcharging.service.WebSocketService;
import jakarta.websocket.*;
import jakarta.websocket.server.ServerEndpoint;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
@RequiredArgsConstructor
@ServerEndpoint(value = "/ocpp")
public class OcppWebSocketServerEndpoint {

    // Static injection workaround since WebSocket Endpoint is managed outside Spring's DI
    private static WebSocketService webSocketService;

    private static final ConcurrentHashMap<String, Session> sessions = new ConcurrentHashMap<>();

    public static void setWebSocketService(WebSocketService service) {
        webSocketService = service;
    }

    @OnOpen
    public void onOpen(Session session) {
        sessions.put(session.getId(), session);
        log.info("WebSocket connected: Session ID = {}", session.getId());
    }

    @OnMessage
    public void onMessage(Session session, String message) {
        try {
            String response = webSocketService.handleMessage(session, message);
            session.getBasicRemote().sendText(response);
        } catch (Exception e) {
            log.error("Error handling WebSocket message", e);
            try {
                session.getBasicRemote().sendText("{\"error\":\"Internal Server Error\"}");
            } catch (IOException ioException) {
                log.error("Error sending error message", ioException);
            }
        }
    }

    @OnClose
    public void onClose(Session session, CloseReason reason) {
        sessions.remove(session.getId());
        log.info("WebSocket closed: Session ID = {}, Reason = {}", session.getId(), reason);
    }

    @OnError
    public void onError(Session session, Throwable throwable) {
        log.error("WebSocket error on session {}: {}", session.getId(), throwable.getMessage(), throwable);
    }

    public static Session getSessionById(String sessionId) {
        return sessions.get(sessionId);
    }
}
