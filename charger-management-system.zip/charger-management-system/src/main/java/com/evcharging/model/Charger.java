package com.evcharging.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Charger {
    @Id
    private String id;

    private String location;
    private String manufacturer;
    private String model;
    private double powerRating;

    @Enumerated(EnumType.STRING)
    private ChargerStatus status;

    private LocalDateTime lastHeartbeat;
    @Column
    private LocalDateTime lastStatusUpdate;
private String sessionId;

}