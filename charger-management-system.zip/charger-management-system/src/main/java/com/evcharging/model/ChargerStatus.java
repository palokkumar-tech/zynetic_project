package com.evcharging.model;



public enum ChargerStatus {
    AVAILABLE,
    CHARGING,
    FAULTED,
    UNAVAILABLE
}