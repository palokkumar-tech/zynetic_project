package com.evcharging.service;

public interface HeartbeatMonitorService {
    void updateHeartbeat(String chargerId);
    void markUnavailableIfNoHeartbeat();
}

