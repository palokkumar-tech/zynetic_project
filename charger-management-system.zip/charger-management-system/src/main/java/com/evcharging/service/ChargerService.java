package com.evcharging.service;

import com.evcharging.dto.BootNotificationRequest;
import com.evcharging.model.Charger;

import java.util.List;

public interface ChargerService {
//    Charger saveOrUpdateCharger(Charger charger);
//    Charger updateStatus(String chargerId, ChargerStatus status);
//    Charger findByChargerId(String chargerId);
//    List<Charger> listAllChargers();
    void registerCharger(BootNotificationRequest req, String chargerId);
    void updateLastHeartbeat(String chargerId);
    void updateChargerStatus(String chargerId, String status);
    void mapChargerToSession(String chargerId, String sessionId);

    Charger findByChargerId(String chargerId);

    List<Charger> listAllChargers();
}
