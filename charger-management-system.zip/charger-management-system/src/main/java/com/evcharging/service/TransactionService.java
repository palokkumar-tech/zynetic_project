package com.evcharging.service;

import com.evcharging.dto.StartTransactionRequest;
import com.evcharging.dto.StopTransactionRequest;
import com.evcharging.model.Transaction;

import java.time.LocalDateTime;
import java.util.List;

public interface TransactionService {
//    Transaction logStartTransaction(StartTransactionRequest req);
//    Transaction logStopTransaction(StopTransactionRequest req);
    List<Transaction> findByChargerIdAndTimeRange(String chargerId, LocalDateTime from, LocalDateTime to);
    Transaction startTransaction(String chargerId, StartTransactionRequest req);
    void stopTransaction(String chargerId, StopTransactionRequest req);
}
