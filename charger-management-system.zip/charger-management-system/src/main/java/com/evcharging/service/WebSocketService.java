package com.evcharging.service;

import jakarta.websocket.Session;

// WebSocketService.java (interface)
public interface WebSocketService {
    void handleMessage(Session session, String message,String chargerId);
    void registerSession(String chargerId, Session session);
}
