package com.evcharging.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class OcppMessageParser {

    public static final ObjectMapper objectMapper = new ObjectMapper();

    public static OcppRequest parse(String message) {
        try {
            JsonNode root = objectMapper.readTree(message);
            if (!root.isArray() || root.size() < 3) {
                throw new IllegalArgumentException("Invalid OCPP message format");
            }

            int messageType = root.get(0).asInt();
            String uniqueId = root.get(1).asText();

            if (messageType == 2) { // CALL (Request)
                String action = root.get(2).asText();
                JsonNode payload = root.get(3);
                return new OcppRequest(uniqueId, action, payload);
            }

            throw new UnsupportedOperationException("Unsupported OCPP message type: " + messageType);
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse OCPP message", e);
        }
    }

    public static String wrapResponse(String action, Object payload) {
        try {
            return objectMapper.writeValueAsString(new Object[]{3, action, payload});
        } catch (Exception e) {
            throw new RuntimeException("Failed to wrap OCPP response", e);
        }
    }

    public static String wrapError(String errorMessage) {
        try {
            return objectMapper.writeValueAsString(new Object[]{
                    4, "error", "InternalError", errorMessage, null
            });
        } catch (Exception e) {
            throw new RuntimeException("Failed to wrap OCPP error", e);
        }
    }

    public static String buildCallResult(String uniqueId, Object payload) {
        try {
            return objectMapper.writeValueAsString(new Object[]{3, uniqueId, payload});
        } catch (Exception e) {
            throw new RuntimeException("Failed to build CallResult", e);
        }
    }

    public static String buildCallError(String uniqueId, String errorCode, String errorDescription) {
        try {
            return objectMapper.writeValueAsString(new Object[]{
                    4, uniqueId, errorCode, errorDescription, null
            });
        } catch (Exception e) {
            throw new RuntimeException("Failed to build CallError", e);
        }
    }
}
