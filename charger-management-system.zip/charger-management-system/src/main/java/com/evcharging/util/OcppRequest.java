package com.evcharging.util;


import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OcppRequest {
    private String uniqueId;
    private String action;
    private JsonNode payload;

    public <T> T getPayloadAs(Class<T> clazz) {
        try {
            return new com.fasterxml.jackson.databind.ObjectMapper().treeToValue(payload, clazz);
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse payload to " + clazz.getSimpleName(), e);
        }
    }
}
